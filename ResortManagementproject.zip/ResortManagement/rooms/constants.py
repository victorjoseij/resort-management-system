class PaymentStatus:
    SUCCESS = "Success"
    FAILURE = "Failure"
    PENDING = "Pending"

class ReservationStatus:
    CHECKED_IN="Checked In"
    CHECKED_OUT="Checked Out"
    RESERVED="Reserved"

# class Message:
#     message_text=None